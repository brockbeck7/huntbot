"""
HuntBot configuration — all secrets via environment variables.
Never hardcode credentials here.
"""

import os

# ── Local LLM server (Ollama / LM Studio / vLLM) ────────────────────────────
LOCAL_LLM_BASE_URL = os.getenv("LOCAL_LLM_BASE_URL", "http://localhost:11434/v1")
LOCAL_LLM_API_KEY  = os.getenv("LOCAL_LLM_API_KEY", "not-needed")

# ── Log backend: "mock" | "file" | "azure" ──────────────────────────────────
LOG_BACKEND        = os.getenv("LOG_BACKEND", "mock").lower()
AZURE_WORKSPACE_ID = os.getenv("AZURE_WORKSPACE_ID", "")
LOCAL_LOG_DIR      = os.getenv("LOCAL_LOG_DIR", "./logs")

# ── Azure AD app registration (for live remediation via MDE API) ─────────────
AAD_TENANT_ID      = os.getenv("AAD_TENANT_ID", "")
AAD_CLIENT_ID      = os.getenv("AAD_CLIENT_ID", "")
AAD_CLIENT_SECRET  = os.getenv("AAD_CLIENT_SECRET", "")


def remediation_enabled() -> bool:
    """True only when all three AAD env vars are populated."""
    return all([AAD_TENANT_ID, AAD_CLIENT_ID, AAD_CLIENT_SECRET])
