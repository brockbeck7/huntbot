# Place your JSONL log exports here for LOG_BACKEND=file
# Filename must match the table name exactly, e.g.:
#   DeviceLogonEvents.jsonl
#   DeviceProcessEvents.jsonl
#   DeviceNetworkEvents.jsonl
#   DeviceFileEvents.jsonl
#   SigninLogs.jsonl
#   EmailEvents.jsonl
#
# Each line must be a valid JSON object.
# Field names should match the schemas in modules/guardrails.py
